require('dotenv').config()
const UserModel = require('../models/User')
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
const gat = require('../middlewares/jwtControl')
const cookie = require('cookie')
const sendResetPassEmail = require('../emailFormats/resetPwdFormat')

async function sendUserPasswordResetEmail (req,res){
    try{
        const {email} = req.body;
        try{
            const user = await UserModel.findOne({ email: email });
            const {tokenID,token,expiration} = gat(user._id);
            user.accessTokens.push({tokenID:tokenID,token:token,expiration:expiration});
            user.save();
            const link = 'http://localhost:3000/login/ResetPassword/';
            await sendResetPassEmail(user,link,tokenID)
            res.send({ "status": "success", message: "Link Sent... Please Check Your Email"});
            
        }catch(err){
            res.send({ "status": "failed",message:'This email is not registered or invalid! Please Try Again'})
        }
    }catch(err){
        res.send({message:'Server error! Please Try Again Later'});
    }
}

async function UserPasswordReset(req,res){
    try{
        const { password, confirmPassword } = req.body;
        const resetTokenID = req.params;
        const tokenID = "NS" + resetTokenID.resetTokenID.toString();
        if (!tokenID) {
            return res.status(403).send({ error: 'Token is missing or invalid' });
        }else{
        try{
            const findUser = await UserModel.findOne({
                'accessTokens.tokenID': tokenID,
              });
    
            if (!findUser) {
                return res.status(401).send({ error: 'User Not Found By Token ID'});
            }else{
                const matchedIndex = findUser.accessTokens.findIndex((token) => token.tokenID === tokenID);
                if (password && confirmPassword) {
                    try {
                        jwt.verify(findUser.accessTokens[matchedIndex].token,process.env.ACCESS_TOKEN_SECRET)
                        if (password !== confirmPassword) {
                            res.send({ "status": "failed", "message": "Password and Confirm Password doesn't match" });
                        }
                        else {
                            const salt = await bcrypt.genSalt(10);
                            const newHashPassword = await bcrypt.hash(password, salt);
                            findUser.password= newHashPassword;
                            findUser.accessTokens.splice(matchedIndex, 1);
                            await findUser.save();
                            res.send({ "status": "success", "message": "Password Reset Successfully" });
                        }
            
                    } catch (error) {
                        console.log(error);
                        res.send({ "status": "failed", "message": "Invalid Token" })
                    }
                }else{
                    res.send({ "status": "failed", "message": "Password and Confirm Password Should Not be Empty" });
                }
            }
            
        }catch(err){
            res.send({ "status": "failed",message:'User is not found by TokenID'})
        }}
    }catch(err){
        res.send({message:'Server error! Please Try Again Later'});
    }
}

module.exports = {sendUserPasswordResetEmail,UserPasswordReset};