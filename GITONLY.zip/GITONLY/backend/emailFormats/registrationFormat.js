const sendEmail = require('../middlewares/email');

async function sendRegistrationSuccessEmail(newUser) {
  try {
    let email = newUser.email;
    let subject="Registration Successful!";
    let html = `
    <html>
    <head>
        <style>
            body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            }
        
            h1 {
            color: #333;
            }
        
            p {
            font-size: 16px;
            line-height: 1.6;
            color: #666;
            }
        
            ul {
            list-style-type: disc;
            padding-left: 20px;
            }
        
            li {
            margin-bottom: 8px;
            }
        
            .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }
        
            .header {
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            }
        
            .footer {
            background-color: #f4f4f4;
            padding: 10px;
            text-align: center;
            }
        </style>
  
    </head>
    <body>
        <h1>Welcome to Our Website!</h1>
        <p>Dear ${newUser.username},</p>
        <p>Your registration was successful.</p>
        
        <p>If you have any questions or need assistance, feel free to contact our support team.</p>
        <p>Thank you again for choosing our platform.</p>
        <p>Best regards,<br>NyaySathi Team</p>
    </body>
    </html>
    `
    sendEmail(email,subject,html);
    }
   catch (error) {
    console.error('Error sending registration success email:', error);
  }
}

module.exports = sendRegistrationSuccessEmail;
