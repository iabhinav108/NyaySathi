const sendEmail = require('../middlewares/email');

async function sendResetPassEmail(User,resetLink,tokenID) {
  try {
    let email = User.email;
    let subject="Reset Your Password";
    let resetToken = tokenID.substring(2);
    let html = `
    <html>
    <head>
        <style>
            body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            }
        
            h1 {
            color: #333;
            }
        
            p {
            font-size: 16px;
            line-height: 1.6;
            color: #666;
            }
        
            ul {
            list-style-type: disc;
            padding-left: 20px;
            }
        
            li {
            margin-bottom: 8px;
            }
        
            .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }
        
            .header {
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            }
        
            .footer {
            background-color: #f4f4f4;
            padding: 10px;
            text-align: center;
            }
        </style>
  
    </head>
    <body>
        <h1>Password Reset Request</h1>
        <p>Dear ${User.username},</p>
        <p>We have received a request to reset your password. To proceed, please use the following reset token:</p>
        <p><strong>Reset Token:</strong> ${resetToken}</p>
        <p>If you initiated this request, please click the link below to reset your password:</p>
        <p><a href="${resetLink}">Reset Password</a></p>
        <p>If you didn't request this, you can safely ignore this email.</p>
        <p>If you have any questions or need assistance, feel free to contact our support team.</p>
        <p>Best regards,<br>NyaySathi Team</p>
    </body>
    </html>
    `
    sendEmail(email,subject,html);
    }
   catch (error) {
    console.error('Error sending registration success email:', error);
  }
}

module.exports = sendResetPassEmail;
