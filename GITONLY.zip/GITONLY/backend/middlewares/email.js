require('dotenv').config();
const mailTP = require('../middlewares/emailConfig');

async function sendEmail(emailAddress, subject, htmlContent) {
  try {
    await mailTP.sendMail({
      from: process.env.EMAIL_FROM,
      to: emailAddress,
      subject: subject,
      html: htmlContent,
    });
  } catch (error) {
    console.log(`Error sending email with subject "${subject}" to ${emailAddress}:`, error);
  }
}

module.exports = sendEmail;
