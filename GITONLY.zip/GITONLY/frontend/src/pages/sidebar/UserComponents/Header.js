import React, { useState,useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Alert,AppBar, Box,Button, IconButton, Toolbar, Typography,Menu,MenuItem, } from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import indiaEmblem from '../../../images/emblem.png'; // Replace with the actual path to your emblem image
import '../../../styles/HeaderStyles.css'; // Add your CSS file here
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import axios from 'axios'

const Header = () => {
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  const [welcomeMessage,setwelcomeMessage] = useState(false);
  const [logoutMessage,setlogoutMessage] = useState(false);


  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get('/api/user/profile'); // Replace with the actual API endpoint
        if (response.data) {
          setwelcomeMessage(response.data.message);
          setTimeout(() => {
            setwelcomeMessage(''); // Clear the welcome message after 5 seconds
          }, 3000);
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };
    fetchUserData();
  }, []);

  const handleLogout = async()=>{
    try {
      const res = await axios.get('/api/user/logout');
      if (res.data.status === 'success') {
        setlogoutMessage(res.data.message);
          setTimeout(() => {
            setlogoutMessage('');
            navigate('/login');
          }, 1500);
        
      }
    } catch (error) {
      console.error('Logout error:', error);
    }
  }

  // Handle menu click
  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const [anchorEl, setAnchorEl] = useState(null);

  const handleUserIconClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <>
      <Box>
        <AppBar component="nav" sx={{ bgcolor: 'black' }}>
          <Toolbar>
            <IconButton
              color="inherit"
              aria-label="open drawer"
              edge="start"
              sx={{
                mr: 2,
                display: { sm: 'none' },
              }}
              onClick={handleDrawerToggle}
            >
              <MenuIcon />
            </IconButton>
            <img src={indiaEmblem} alt="Emblem of India" className="india-emblem" />
            <Typography
              color="goldenrod"
              variant="h6"
              component="div"
              sx={{ flexGrow: 1 }}
            >
              NyaySathi
            </Typography>
              <Toolbar>
            <Box sx={{
              display: 'flex',
              maxWidth: '800px',
              width: '100%',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}>
              <Button
                color="inherit"
                onClick={() => navigate('/dashboard/applyPreTrial')}
              >
                Apply Pre-trial
              </Button>
              <Button
                color="inherit"
                onClick={() => navigate('/dashboard/ManagePreTrials')}
              >
                Manage Your Pre-Trials
              </Button>
              <Button
                color="inherit"
                onClick={() => navigate('/dashboard/Notifications')}
              >
                Notifications
              </Button>
              <Button
                color="inherit"
                onClick={() => navigate('/dashboard/historyPreTrials')}
              >
                History Log
              </Button>
              <Button
                color="inherit"
                onClick={() => navigate('/dashboard/feedback')}
              >
                Feedback
              </Button>
              <Button color="inherit" onClick={handleUserIconClick}>
                <AccountCircleIcon />
              </Button>
            </Box>
              </Toolbar>
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleClose}
      >
        <MenuItem
          onClick={() => {
            navigate('/dashboard/updateProfile');
            handleClose();
          }}
        >
          Update Profile
        </MenuItem>
        <MenuItem
          onClick={() => {
            handleLogout();
            handleClose();
          }}
        >
          Logout
        </MenuItem>
      </Menu>
            
        </Toolbar>
        </AppBar>
        
      </Box>
      <div style={{ marginBottom: '4rem' }}></div>
      {welcomeMessage && <Alert severity="success">{welcomeMessage}</Alert>}
      {logoutMessage && <Alert severity="success">{logoutMessage}</Alert>}
      <div style={{ marginBottom: '6rem' }}></div>
      
    </>
  );
};

export default Header;
