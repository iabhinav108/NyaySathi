import React, { useState } from 'react';
import { TextField, Button, Box, Alert, Typography, CssBaseline } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import Layout from '../components/Layout';
import { Container } from '@mui/system';

const ResetPassword = () => {
  const [resetToken, setResetToken] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState({
    status: false,
    msg: '',
    type: '',
  });
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      if (resetToken && password && confirmPassword) {
        if (password === confirmPassword) {
          const res = await axios.post(`/api/login/resetPass/${resetToken}`, {
            password,
            confirmPassword,
          });

          if (res.data.status === 'success') {
            console.log('API Response: Success', res);
            navigate('/login');
          } else {
            console.log('API Response: Failed');
            setError({ status: true, msg: res.data.message, type: 'error' });
          }
        } else {
          setError({ status: true, msg: 'Passwords do not match', type: 'error' });
        }
      } else {
        setError({ status: true, msg: 'All fields are required', type: 'error' });
      }
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <Layout>
      <Box
        sx={{
          my: 4,
          textAlign: 'center',
          p: '12vh',
          '@media (max-width:600px)': {
            mt: 0,
          },
        }}
      ></Box>
      <Container component="main" maxWidth="xs">
        <CssBaseline />
        <div>
          <Typography variant="h3" sx={{ my: 1, marginTop: 0, marginBottom: 2 }}>
            Reset Password
          </Typography>
          <form noValidate sx={{ my: 2, padding: 2 }} id="reset-password-form" onSubmit={handleSubmit}>
            {error.status ? <Alert severity={error.type}>{error.msg}</Alert> : ''}
            <TextField
              margin="dense"
              required
              fullWidth
              id="resetToken"
              name="resetToken"
              label="Reset Token"
              value={resetToken}
              onChange={(e) => setResetToken(e.target.value)}
            />
            <TextField
              margin="dense"
              required
              fullWidth
              id="password"
              name="password"
              label="New Password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <TextField
              margin="dense"
              required
              fullWidth
              id="confirmPassword"
              name="confirmPassword"
              label="Confirm Password"
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
            />
            <Box sx={{ my: 2, display: 'flex', justifyContent: 'space-between' }}>
              <Button type="submit" variant="contained">
                Reset Password
              </Button>
            </Box>
          </form>
        </div>
      </Container>
    </Layout>
  );
};

export default ResetPassword;
