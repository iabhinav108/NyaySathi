import React, { useState } from 'react';
import { TextField, Button, Box, Alert, Typography, CssBaseline } from '@mui/material';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import Layout from '../components/Layout';
import { Container } from '@mui/system';

const ForgotPassword = () => {
  const [email, setEmail] = useState('');
  const [error, setError] = useState({
    status: false,
    msg: '',
    type: '',
  });
  const [successMessage, setSuccessMessage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      if (email) {
        const res = await axios.post('/api/login/forgotPass', { email }); 

        if (res.data.status === 'success') {
          setSuccessMessage(res.data.message);
        } else {
          console.log('API Response: Failed');
          setError({ status: true, msg: res.data.message, type: 'error' });
        }
      } else {
        setError({ status: true, msg: 'Email is required', type: 'error' });
      }
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <Layout>
      <Box
        sx={{
          my: 4,
          textAlign: 'center',
          p: '12vh',
          '@media (max-width:600px)': {
            mt: 0,
          },
        }}
      ></Box>
      <Container component="main" maxWidth="xs">
        <CssBaseline />
        <div>
          <Typography variant="h3" sx={{ my: 1, marginTop: 0, marginBottom: 2 }}>
            Forgot Password
          </Typography>
          <form noValidate sx={{ my: 2, padding: 2 }} id="forgot-password-form" onSubmit={handleSubmit}>
            {error.status ? <Alert severity={error.type}>{error.msg}</Alert> : ''}
            {successMessage && <Alert severity="success">{successMessage}</Alert>}
            <TextField
              margin="dense"
              required
              fullWidth
              id="email"
              name="email"
              label="Email Address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <Box sx={{ my: 2, display: 'flex', justifyContent: 'space-between' }}>
              <Button type="submit" variant="contained">
                Reset Password
              </Button>
              <NavLink to="/login">
                <Button variant="outlined" color="primary">
                  Back to Login
                </Button>
              </NavLink>
            </Box>
          </form>
        </div>
      </Container>
    </Layout>
  );
};

export default ForgotPassword;
