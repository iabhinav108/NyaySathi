import React from 'react'
import Header from './Header'
import Footer from './Footer'
import "../styles/Body.css"
const Layout = ({ children}) => {
  return (
    <>
      <Header />
      <div className='BodyContent'>{children}</div>
      <Footer />
    </>
  )
}

export default Layout
