# NyaySathi
SIH 2023
Smart BU Hackathon

Team Name: Tech Titans
Team Leader: Abhinav Srivastava
Team Members - V Harshath, Shivang Goyal, Hasbi Fathima, Asmit Parida, Nishtha Nagar

Youtube Video Link Demonstrating the workings of our project:https://youtu.be/yw4k0lUD7_w

Instructions to Get Started with this Project:
Firstly install node js framework from the original website. Refer to this link:https://nodejs.org/en

Next, Once you have downloaded the Project Files or cloned this repository, proceed to type these lines below in a terminal(Powershell):
```bash
cd frontend
npm i -G
npm start
```
Open another terminal within the project directory set. 
```bash
cd backend
npm i -G
npm start
```
It is advised to install the npm package files as a global dependency, so that all the files run without producing any error.
